import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.protobuf.generated.*;


public class FirstHBaseClient {
    public static void main(String[] args) throws IOException {

        Configuration config = HBaseConfiguration.create();

        Connection connection = ConnectionFactory.createConnection(config);
        try {


            Table table = connection.getTable(TableName.valueOf("emp"));
            try {

                Scan s = new Scan();
                ResultScanner scanner = table.getScanner(s);
                try {

                    for (Result rr = scanner.next(); rr != null; rr = scanner.next()) {
                        // print out the row we found and the columns we were looking for
                        System.out.println("Found row: " + rr);
                    }

                } finally {

                    scanner.close();
                }

            } finally {
                if (table != null) table.close();
            }
        } finally {
            connection.close();
        }
    }
}